---
name: vaada-hypothesis-engine
description: Generate, adversarially critique, compare, and judge falsifiable scientific hypotheses using a frozen, validated Nyaya causal-map snapshot. Use for Vaada hypothesis cycles, Pramana-ranked evidence comparison, evidence-grounded scientific debate, hypothesis selection, or experimental-plan proposals. Do not use for PDF ingestion, claim extraction, graph mutation, or direct laboratory execution.
---

# Vaada Hypothesis Engine

Act only as the orchestrator. Do not roleplay or silently perform the Proponent, Opponent, or Judge's scientific work. Invoke distinct roles using the Markdown contracts under `references/role-contracts/`, exactly one scientific role at a time.

Before a cycle, read completely:

- `references/docs/workflow.md`;
- `references/docs/pramana-hierarchy.md` and `references/evaluation-policy.yaml`;
- the applicable role, Tarka, knowledge-pool, evaluation, and output documents;
- `references/data-contract.md`;
- the applicable schemas under `references/schemas/`.

## Frozen intake

Obtain the research question and explicit snapshot path. Record its SHA-256 and freeze the permitted input set. Validate every referenced variable, causal claim, synthesized causal edge, source, evidence object, and promotion decision. A Vyapti link is permitted only when its `VYP-...` edge is present in the frozen snapshot, has a corresponding promoted decision, and records `projection_eligible: true`. Retain correlations, hypotheses, nulls, and contradictions only in their recorded non-causal roles.

## Sequential Vaada

1. Invoke the Proponent with the frozen intake and permitted snapshot objects.
2. Validate each structured hypothesis and every identifier.
3. Invoke the Opponent with only validated hypotheses and permitted objects.
4. Validate the critiques.
5. Return each critique to the original Proponent context for exactly one reinforce, narrow, revise, or concede response.
6. Validate all defenses and revisions.
7. Invoke the Judge with only validated structured artifacts and the frozen comparison policy.
8. Apply validity gates, then compare evidence lexicographically from Pramana Grade 5 to Grade 1. Never replace hierarchical precedence with a weighted average.
9. Validate exactly one verdict per hypothesis and one comparison outcome for each comparable pair.
10. When no hypothesis dominates, return `Unresolved` and propose a discriminating experiment; never force a winner.
11. Save a traceable run without mutating the input snapshot.

If the host cannot preserve distinct role contexts or resume the original Proponent context for defense, stop and report the runtime limitation. Pass only structured records and concise rationales between roles, never hidden reasoning.

The engine may propose an experiment plan conforming to `references/schemas/experiment-plan.schema.json`, but it must set execution status to `not_authorized` and must not send PUDA commands. A separately installed equipment or simulation skill may execute only after explicit human approval. Results return through the extractor into a later snapshot.

Stop on schema failures, missing IDs, impermissible evidence, causal promotion, lost scope or uncertainty, unversioned policy, or any need for silent scientific repair.
