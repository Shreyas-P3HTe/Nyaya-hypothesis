# Hierarchical Comparison Example

## Research question

Which of two mechanisms better explains the same observed reduction in outcome variability?

## Surviving hypotheses

- `H-A`: the intervention directly changes the outcome-generating mechanism.
- `H-B`: the intervention acts indirectly through a measured mediator.

Both hypotheses pass schema, falsifiability, Vyapti, duplication, and fallacy gates.

## Independent evidence vectors

```yaml
H-A:
  grade_5: 0
  grade_4: 1
  grade_3: 1
  grade_2: 0
  grade_1: 1

H-B:
  grade_5: 0
  grade_4: 0
  grade_3: 4
  grade_2: 2
  grade_1: 3
```

The vectors first differ at Grade 4. `H-A` is provisionally supported because one applicable Grade-4 evidence family takes precedence over any quantity of Grade-3 or lower evidence.

## Equal-grade conflict

If both vectors instead equal:

```text
[0, 1, 1, 0, 1]
```

the Judge checks Vyapti scope/path validity, then Tarka resolution. If both remain equal, the outcome is `Unresolved`.

## Discriminating experiment

Hold the mediator constant while varying the intervention:

- `H-A` predicts the outcome still changes.
- `H-B` predicts the effect disappears or materially weakens.

The experiment plan records both predictions and remains `not_authorized` until human approval.
