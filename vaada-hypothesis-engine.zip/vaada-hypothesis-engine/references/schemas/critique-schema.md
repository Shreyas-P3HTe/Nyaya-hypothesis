# Critique Schema

## Fields

| Field | Type | Description |
|---|---|---|
| `critique_id` | string | Unique identifier |
| `hypothesis_id` | string | Hypothesis being critiqued |
| `attack_type` | enum[`alternative_causal_explanation`, `boundary_condition_violation`, `confounding_variable`, `counter_example`, `mediator_omission`, `moderator_omission`, `causal_direction_error`, `directness_error`, `scope_mismatch`, `falsifiability_failure`, `novelty_or_duplication`, `no_substantive_objection`] | Strongest supported finding |
| `counterargument` | string | The specific counterargument text |
| `attempted_attack_types` | list[attack_type except `no_substantive_objection`] | Applicable attacks genuinely attempted before selecting the strongest finding |
| `target_effect` | string | Effect or prediction independently assessed by this critique |
| `fallacy_flag` | enum[`none`, `savyabhicara`, `viruddha`, `satpratipaksha`, `asiddha`, `badhita`] | Detected fallacy, if any |
| `duplication_flag` | boolean | Whether this hypothesis duplicates an existing one |
| `novelty_flag` | enum[`novel`, `low-novelty`, `duplicate`] | Novelty assessment |
| `no_substantive_objection` | boolean | True only if a genuine search found no valid attack |
| `cited_evidence` | list[evidence_id] | Existing `EVD-...` evidence used to support the critique |
| `cited_vyapti_edges` | list[edge_id] | Existing promoted, projection-eligible `VYP-...` edges supporting the critique |

When `no_substantive_objection` is true, `attack_type` must be
`no_substantive_objection`, `attempted_attack_types` must be non-empty, and
`counterargument` must summarize the completed checks without inventing an objection.
Otherwise `attack_type` must name the strongest supported attack and
`no_substantive_objection` must be false.

## Example (YAML)

```yaml
critique_id: C-2026-0731-001a
hypothesis_id: H-2026-0731-001
attack_type: confounding_variable
counterargument: "Dopant X concentration correlates with increased grain-boundary density, which independently affects migration barrier; the causal map does not isolate these effects"
attempted_attack_types: [alternative_causal_explanation, boundary_condition_violation, confounding_variable, counter_example, mediator_omission, moderator_omission, causal_direction_error, directness_error, scope_mismatch, falsifiability_failure, novelty_or_duplication]
target_effect: "Ionic migration barrier"
fallacy_flag: asiddha
duplication_flag: false
novelty_flag: novel
no_substantive_objection: false
cited_evidence: [EVD-000031]
cited_vyapti_edges: [VYP-000001]
```
