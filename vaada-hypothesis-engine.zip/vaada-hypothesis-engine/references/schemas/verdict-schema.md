# Verdict Schema

## Fields

| Field | Type | Description |
|---|---|---|
| `verdict_id` | string | Unique verdict identifier |
| `hypothesis_id` | string | Hypothesis being judged |
| `policy_version` | string | Frozen evaluation-policy version |
| `gate_results` | list[object] | Gate name, pass/fail, and rationale |
| `evidence_assessment` | object | Supporting, contradicting, qualifying, boundary, and inconclusive evidence families |
| `evidence_vector` | object | Independent net evidence counts at Grades 5 through 1 |
| `critique_resolution` | list[object] | Resolution status for every critique |
| `verdict` | enum | `Provisionally_supported`, `Rejected`, `Revise`, `Unresolved`, `Exploratory`, or `Escalate` |
| `comparison_ids` | list[string] | Pairwise comparisons informing the verdict |
| `rationale` | string | Human-readable, traceable explanation |
| `driving_objects` | list[string] | Existing `EVD`, `VYP`, critique, or defense identifiers |
| `next_action` | string | Revision, human review, or discriminating experiment |

## Evidence vector

```yaml
evidence_vector:
  grade_5: 0
  grade_4: 1
  grade_3: 0
  grade_2: -1
  grade_1: 2
```

Each component equals independent supporting families minus independent contradicting families at that grade. Counts must be traceable to `evidence_assessment`. Qualifying, out-of-scope, boundary-defining, and inconclusive evidence does not enter the vector.

## Gate result

Each gate result contains:

- `gate`: schema validity, falsifiability, measurable prediction, Vyapti eligibility, duplication, Viruddha, Badhita, scope compatibility, or same-grade conflict;
- `passed`: boolean;
- `rationale`: concise explanation;
- `object_ids`: existing identifiers that determined the result.

## Example

```yaml
verdict_id: VER-2026-001
hypothesis_id: H-2026-001
policy_version: vaada-comparison-v1.0
gate_results:
  - gate: vyapti_eligibility
    passed: true
    rationale: The cited edge is promoted and projection-eligible.
    object_ids: [VYP-000001]
evidence_assessment:
  supporting_families: [EFAM-000007]
  contradicting_families: []
  qualifying_families: []
  boundary_families: []
  inconclusive_families: []
  independence_notes: []
evidence_vector:
  grade_5: 0
  grade_4: 0
  grade_3: 1
  grade_2: 0
  grade_1: 0
critique_resolution:
  - critique_id: C-2026-001
    status: addressed
    rationale: The revised scope excludes the documented counterexample.
verdict: Provisionally_supported
comparison_ids: [CMP-2026-001]
rationale: This hypothesis leads at the highest differing Pramana grade and passes all gates.
driving_objects: [EVD-000014, VYP-000001, C-2026-001]
next_action: Seek direct experimental evidence.
```
