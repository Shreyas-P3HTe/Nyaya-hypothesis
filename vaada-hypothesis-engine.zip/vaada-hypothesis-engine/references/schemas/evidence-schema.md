# Evidence Schema

## Fields

| Field | Type | Description |
|---|---|---|
| `evidence_id` | string | Unique `EVD-...` identifier |
| `evidence_family_id` | string | Independent source or replication family used for counting |
| `source_type` | enum | `published_literature`, `preprint`, `proxy_characterization`, `simulation`, `benchside_experiment`, `analogy`, `expert_testimony`, or `internal_report` |
| `description` | string | What the evidence records |
| `pramana_type` | enum | Fixed epistemic type listed below |
| `pramana_grade` | integer 0-5 | Grade fixed by `pramana_type` |
| `evidence_role` | enum | `supports`, `contradicts`, `qualifies`, `defines_boundary`, or `inconclusive` |
| `hypothesis_ids` | list[string] | Hypotheses to which the role applies |
| `scope_compatible` | boolean | Whether the evidence matches the current system and conditions |
| `scope_note` | string | Scope match or mismatch explanation |
| `reference` | string | Existing source, passage, dataset, or experiment-log identifier |
| `independence_status` | enum | `independent`, `same_family`, or `unknown` |

## Fixed type-grade mapping

| `pramana_type` | Required grade |
|---|---:|
| `pratyaksha_direct_experimental` | 5 |
| `anumana_strong_causal_inference` | 4 |
| `anumana_indirect_empirical` | 3 |
| `upamana_analogy` | 2 |
| `shabda_testimony` | 1 |
| `unsupported` | 0 |

The type determines the grade. An artifact with a mismatched type and grade fails validation. The Judge may not change either field during a frozen cycle.

Only scope-compatible evidence contributes to the evidence vector. Repeated observations within one `evidence_family_id` count once; retain the strongest applicable item in that family.

## Example

```yaml
evidence_id: EVD-000014
evidence_family_id: EFAM-000007
source_type: simulation
description: Simulation predicts a reduction in the target outcome under the registered intervention.
pramana_type: anumana_indirect_empirical
pramana_grade: 3
evidence_role: supports
hypothesis_ids: [H-2026-001]
scope_compatible: true
scope_note: Uses the same material system and operating range.
reference: RUN-SIM-2026-0715-042
independence_status: independent
```
