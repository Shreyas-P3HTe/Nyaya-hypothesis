# Hypothesis Schema

## Fields

| Field | Type | Description |
|---|---|---|
| `hypothesis_id` | string | Unique `H-...` identifier |
| `research_question_id` | string | Research question shared by comparable hypotheses |
| `comparison_group_id` | string | Group within which pairwise comparison is scientifically valid |
| `pratijna` | string | Claim being asserted |
| `hetu` | string | Causal or logical reason |
| `drshtanta` | string | Supporting example, analogy, or precedent |
| `vyapti_links` | list[object] | Promoted, projection-eligible synthesized causal edges |
| `mechanism` | object | Proposed pathway with declared mediators and moderators |
| `predictions` | list[object] | Measurable directional predictions |
| `scope_conditions` | list[string] | Conditions under which the claim is expected to hold |
| `falsification_criteria` | list[string] | Observations that would count against the hypothesis |
| `uncertainty` | object | Explicit uncertainty and its basis |
| `evidence_gaps` | list[string] | Missing evidence or measurements |
| `source` | enum[`llm`, `human`, `hybrid`] | Origin |
| `cited_evidence` | list[string] | Existing `EVD-...` identifiers |
| `round_count` | integer | Completed critique-defense rounds |
| `status` | enum | `draft`, `under_critique`, `revised`, `finalized`, or `conceded` |

## Vyapti link

| Field | Type | Description |
|---|---|---|
| `edge_id` | string | Existing `VYP-...` edge identifier |
| `edge_version` | integer | Frozen version of the synthesized edge |
| `source_variable_id` | string | Existing cause variable |
| `target_variable_id` | string | Existing effect variable |
| `relation_type` | enum from causal-map schema | Recorded causal or mechanistic relation |
| `polarity` | enum from causal-map schema | Recorded direction |
| `directness` | enum | `direct`, `indirect`, `total`, or `unknown` |
| `pramana_type` | enum | Type already recorded for the frozen edge |
| `pramana_grade` | integer 1-5 | Grade already recorded for the edge; type determines grade |
| `scope_note` | string | Preserved system and boundary scope |
| `projection_eligible` | const true | Required for ranked hypotheses |

The link must resolve to the exact edge and version in the frozen snapshot. Source-specific `CLM-...` claims remain provenance for the edge but are not substituted for the synthesized Vyapti link.

## Mechanism

| Field | Type | Description |
|---|---|---|
| `description` | string | Proposed pathway, marked as proposed when not established |
| `mediator_variable_ids` | list[string] | Existing mediators |
| `moderator_variable_ids` | list[string] | Existing moderators |

## Prediction

| Field | Type | Description |
|---|---|---|
| `prediction_id` | string | Stable prediction identifier |
| `statement` | string | Measurable predicted observation |
| `expected_direction` | enum | `increase`, `decrease`, `no_effect`, `non_monotonic`, or `context_dependent` |
| `measurement` | string | Required observable and method |
| `temporal_order` | string | Expected temporal order |

## Defense record

Each critique receives one structured response. A defense never overwrites the original hypothesis.

| Field | Type | Description |
|---|---|---|
| `defense_id` | string | Unique defense identifier |
| `hypothesis_id` | string | Hypothesis being defended |
| `critique_ids` | list[string] | Critiques addressed |
| `disposition` | enum | `reinforce`, `narrow`, `revise`, or `concede` |
| `response` | string | Concise evidence-grounded response |
| `changed_fields` | list[object] | Field path, previous value, updated value, and rationale |
| `revised_hypothesis` | object or null | Complete revised object for narrow or revise |

## Example

```yaml
hypothesis_id: H-2026-001
research_question_id: RQ-2026-001
comparison_group_id: CG-2026-001
pratijna: Increasing intervention intensity reduces outcome variability.
hetu: The intervention alters an intermediate response that controls variability.
drshtanta: A related controlled system shows the same mediated direction.
vyapti_links:
  - edge_id: VYP-000001
    edge_version: 1
    source_variable_id: VAR-INTERVENTION-INTENSITY
    target_variable_id: VAR-OUTCOME-VARIABILITY
    relation_type: mediated_causal
    polarity: negative
    directness: indirect
    pramana_type: anumana_strong_causal_inference
    pramana_grade: 4
    scope_note: System A under the recorded operating range.
    projection_eligible: true
mechanism:
  description: Intervention intensity changes an intermediate response that reduces variability.
  mediator_variable_ids: [VAR-INTERMEDIATE-RESPONSE]
  moderator_variable_ids: []
predictions:
  - prediction_id: PRED-001
    statement: Outcome variability decreases across the permitted intervention range.
    expected_direction: decrease
    measurement: Standard deviation of the registered outcome.
    temporal_order: Intervention precedes outcome measurement.
scope_conditions:
  - System A under the recorded operating range.
falsification_criteria:
  - Variability does not decrease when the intermediate response is controlled.
uncertainty:
  level: moderate
  description: No direct experiment isolates the mediator in this system.
evidence_gaps:
  - Controlled mediator experiment.
source: hybrid
cited_evidence: [EVD-000001]
round_count: 1
status: under_critique
```
