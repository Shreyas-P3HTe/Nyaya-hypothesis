# Evaluation

## Purpose

Measure whether the engine applies its frozen contracts consistently and whether its provisional decisions are useful after experimental follow-up.

## Contract fidelity

- **Schema-valid artifact rate** - proportion of hypotheses, critiques, defenses, verdicts, and comparisons passing validation.
- **Identifier resolution rate** - proportion of cited `VAR`, `CLM`, `VYP`, and `EVD` identifiers resolving to the frozen snapshot.
- **Hierarchy violation rate** - cases where lower-grade evidence improperly overrides higher-grade evidence; target zero.
- **Double-counting rate** - evidence families counted more than once without documented independence; target zero.
- **Forced-winner rate** - unresolved equal comparisons incorrectly assigned a winner; target zero.

## Reasoning quality

- **Fallacy catch rate** - proportion of seeded or expert-labelled Hetvabhasa flaws correctly identified.
- **Critique specificity** - proportion of critiques citing a concrete mechanism, scope mismatch, causal edge, or evidence item.
- **Defense resolution rate** - proportion of critiques directly addressed rather than rhetorically restated.
- **Discriminating-experiment quality** - proportion of unresolved comparisons receiving a feasible test with genuinely divergent predictions.

## Downstream validity

- **Provisional-support confirmation rate** - proportion of provisionally supported hypotheses later confirmed by relevant higher-grade evidence.
- **False-rejection rate** - rejected hypotheses later supported by stronger applicable evidence.
- **Unresolved-to-resolution rate** - unresolved comparisons resolved by the proposed experiment.
- **Human override rate** - frequency and direction of expert overrides, with rationale.

## Calibration

Evaluate new policy versions against a fixed suite containing:

- one hypothesis with stronger support;
- one hypothesis defeated by stronger contradiction;
- an equal-grade conflict requiring `Unresolved`;
- a Viruddha case;
- a Badhita case;
- duplicated evidence from one source family;
- an out-of-scope high-grade item;
- two hypotheses requiring a discriminating experiment.

Use blind expert review where practical. Never tune the hierarchy to make a preferred hypothesis win. Changes require a new policy version and must not alter prior traces.
