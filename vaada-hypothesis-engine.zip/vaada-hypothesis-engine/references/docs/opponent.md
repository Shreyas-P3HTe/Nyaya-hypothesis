# Opponent

## Role
Attacks each candidate hypothesis to stress-test it before it reaches the Judge. Composed of an adversarial counter-argument agent, a fallacy checker, and a deduplication/novelty checker.

## Components

### Adversarial Counter-Argument Agent (Tarka)
- Generates the single strongest available counterargument against the hypothesis, not a list of weak objections.
- Must attempt at least one of the following attack types (see `tarka-rules.md` for full list):
  - Alternative causal explanation for the same observation
  - Boundary-condition violation (the causal map's `scope_conditions` do not cover this case)
  - Confounding variable not accounted for
  - Counter-example from existing literature or data
  - Missing mediator or incorrectly collapsed mediated path
  - Missing moderator or context-dependent effect
  - Incorrect causal direction or directness
  - Scope mismatch
  - Unfalsifiability, i.e the null or opposing hypothesis cannot be made
  - Novelty or duplication failure

### Fallacy Checker (Hetvabhasa)
- Screens the Proponent's `hetu` (reason) against known fallacy categories:
  - `savyabhicara` -- inconsistent/erratic reason (works sometimes, not reliably)
  - `viruddha` -- reason that actually contradicts the claim
  - `satpratipaksha` -- reason equally balanced by an opposing reason
  - `asiddha` -- unproven/unestablished reason
  - `badhita` -- reason contradicted by stronger evidence
- Flags any hypothesis whose reason falls into one of these categories, with the specific category named in the critique output.

### Deduplication and Novelty Checker
- Compares the hypothesis against the Knowledge Pool's prior hypothesis archive and existing literature claims.
- Flags as `duplicate` if functionally identical to an existing accepted or rejected hypothesis.
- Flags as `low-novelty` if it is a minor variant of prior work without a meaningfully new causal claim.

## Output
Each Opponent pass produces a structured critique object (see `schemas/critique-schema.md`) containing the counterargument, any fallacy flags, and novelty/duplication status.

## Constraints

- The Opponent must always produce at least one substantive critique attempt per round -- an empty or purely affirming critique is treated as a system error, not a valid "no objection" result.
- The Opponent must record all applicable attempted attack types before selecting the strongest supported finding.
- If genuinely no weakness is found after a real attempt, the critique object must use `attack_type: no_substantive_objection`, set `no_substantive_objection: true`, and summarize the completed checks rather than inventing an objection.
- Promoted, projection-eligible causal-edge IDs may be cited through `cited_vyapti_edges`; raw, rejected, or unresolved literature claims are forbidden as causal grounding.
