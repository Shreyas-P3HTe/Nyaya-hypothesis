# Tarka Rules (Counterfactual Critique Logic)

## Purpose
Defines how the Opponent constructs counterfactual critiques and how the Fallacy Checker screens reasons (`hetu`).

## Attack Types (Opponent must attempt every applicable type per hypothesis)

1. **Alternative causal explanation** -- propose a different mechanism that equally explains the observed pattern.
2. **Boundary-condition violation** -- show the hypothesis's causal-map edge does not cover the specific scope of the current claim.
3. **Confounding variable** -- identify a variable correlated with both the proposed cause and effect that has not been ruled out.
4. **Counter-example** -- cite a specific case in the literature or Knowledge Pool where the proposed mechanism did not produce the expected outcome.
5. **Mediator omission** -- test whether an indirect pathway was collapsed into a direct claim.
6. **Moderator omission** -- test whether the effect changes under an omitted context or parameter.
7. **Causal direction error** -- test whether the proposed direction reverses or exceeds the permitted graph.
8. **Directness error** -- test whether direct, indirect, mediated, and total effects were preserved.
9. **Scope mismatch** -- compare system, population, intervention, measurement, temporal, and boundary scope.
10. **Falsifiability failure** -- test whether the prediction and opposing/null result can be operationalized.
11. **Novelty or duplication failure** -- compare the proposal with existing hypotheses and accepted claims.

## Fallacy Categories (Hetvabhasa)

| Fallacy | Definition | Detection Rule |
|---|---|---|
| Savyabhicara | Erratic/inconsistent reason -- holds in some cases, not others, without explanation | Reason correlates with outcome in <  a configurable threshold (e.g., 70%) of retrieved analogous cases |
| Viruddha | Reason contradicts the very claim it is meant to support | Logical check: does `hetu`, if followed to its conclusion, negate `pratijna`? |
| Satpratipaksha | Reason is exactly counterbalanced by an equally strong opposing reason | Opponent finds a same-grade evidence item supporting the opposite claim |
| Asiddha | Reason itself is unproven or not established | Cited `hetu` has no Pramana grade 2 or higher supporting it |
| Badhita | Reason is contradicted by stronger, already-established evidence | A Grade 4-5 evidence item directly contradicts the `hetu` |

## Critique Quality Requirements

- The counterargument must be the *strongest* available, not merely the first found -- the Opponent records all applicable attempted types before finalizing.
- Vague objections (e.g., "this may not always be true") are insufficient; the critique must cite a specific mechanism, source, or case.
- If the Opponent cannot find a substantive objection after a genuine attempt, it must explicitly record `no_substantive_objection: true` with the search performed, rather than fabricating a weak one.

## Resolution

A critique is considered "addressed" only if the Proponent's defense (see `proponent.md`) directly responds to the specific attack type raised -- a generic restatement of the original hypothesis does not count as addressing the critique.

## Guardrails

The point of critique is to enrich the knowledge pool, not to simply defeat the other side. Proponents as well as Opponent should refrain from Vitanda and Jalpa 

| Feature | Vada (Discussion) | Jalpa (Disputation/Wrangling) | Vitanda (Cavil/Quibble) |
|---|---|---|
| Primary Goal | Ascertain the ultimate truth (Tattva-nirnaya) | Secure victory over the opponent (Vijaya) | Destroy the opponent's argument |
| Attitude | "Cooperative, honest, objective" | "Competitive, hostile, opportunistic" | "Skeptical, purely destructive" |
| Stance | Proposes and defends a positive thesis | Proposes and defends a positive thesis | Has no positive thesis of its own |
| Tactics | Uses valid evidence (Pramana) and logical reasoning (Tarka) | "Employs tricks: quibbling (Chhala), false generalizations (Jati), and evasion (Nigrahasthana)" | Employs the same tricky tactics as Jalpa to dismantle the other side |
