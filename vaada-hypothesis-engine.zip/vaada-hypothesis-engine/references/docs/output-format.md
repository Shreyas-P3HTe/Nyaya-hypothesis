# Output Format

## Purpose

Define the final, auditable report delivered to the human scientist after one or more Vaada cycles.

## Required sections

1. **Run summary** - research question, scope, snapshot ID and hash, policy version, and hypothesis counts.
2. **Validity-gate results** - pass or fail result and rationale for every hypothesis.
3. **Evidence vectors** - independent support and contradiction counts at Grades 5 through 1.
4. **Pairwise comparisons** - decisive grade or permitted tiebreaker for each comparable pair.
5. **Provisionally supported hypotheses** - surviving leaders, explicitly described as provisional.
6. **Unresolved comparisons** - non-dominated hypotheses and the required discriminating observation.
7. **Revise, exploratory, escalated, and rejected items** - grouped separately with traceable reasons.
8. **Open evidence gaps and experiment plans** - plans remain `not_authorized`.

## Hypothesis entry

Each entry includes:

- `hypothesis_id`, `pratijna`, `hetu`, and `drshtanta`;
- referenced `VYP-...` edges and `EVD-...` evidence items;
- gate results;
- `evidence_vector` in Grade 5 to Grade 1 order;
- strongest critique and defense disposition;
- verdict and rationale;
- suggested next step;
- trace pointer.

## Ranking rule

Do not publish a scalar score. Order surviving hypotheses using the frozen hierarchical policy:

1. lexicographic Pramana evidence vector;
2. Vyapti scope/path tiebreaker when vectors are equal;
3. Tarka-resolution tiebreaker when still equal;
4. stable hypothesis ID ordering only for display when the scientific result remains tied.

A display order must never be described as a scientific winner when the comparison outcome is `Unresolved`.

## Traceability

Every claim in the report must resolve to a structured artifact and permitted snapshot object. Missing evidence remains missing. Never fill nulls with narrative estimates.

See `../examples/hierarchical-comparison.md` for the canonical comparison example.
