# Workflow

## Execution cycle

Run one repeatable, sequential Vaada cycle per research question. A question may produce several competing hypotheses, but each scientific role remains isolated and every structured artifact passes validation before the next role receives it.

## Step 0 - intake and freeze

- Receive the research question, scope, permitted local paths, and frozen knowledge-map snapshot.
- Record the snapshot SHA-256 and comparison-policy version.
- Resolve every variable, `CLM-...` claim, `VYP-...` edge, `EVD-...` evidence item, source, and promotion decision.
- Check the prior-hypothesis archive for exact duplicates.

## Step 1 - Proponent generation

- Generate one or more falsifiable hypotheses.
- Express each as `pratijna`, `hetu`, and `drshtanta`.
- Include one or more projection-eligible `VYP-...` links, a mechanism, measurable predictions, falsification criteria, scope, uncertainty, and evidence gaps.
- Permit human-authored or human-edited hypotheses with their origin recorded.

## Step 2 - Vyapti validation

- Confirm each linked edge exists in the frozen snapshot and is promoted and projection-eligible.
- Preserve its version, direction, directness, polarity, temporal order, and scope.
- Route a falsifiable hypothesis without eligible grounding to `Exploratory`; do not fabricate a causal link.

## Step 3 - Opponent critique

- Attempt every applicable Tarka attack type.
- Select the strongest supported critique.
- Run Hetvabhasa, duplication, and novelty checks.
- Record all attempted attacks and cited `EVD-...` and `VYP-...` identifiers.

## Step 4 - Proponent defense

- Return the validated critique to the original Proponent context.
- Require exactly one disposition: reinforce, narrow, revise, or concede.
- Validate all changed fields and identifiers.

## Step 5 - Judge validity gates

- Apply schema, falsifiability, Vyapti, duplication, Viruddha, Badhita, and scope gates.
- Assign `Rejected`, `Revise`, or `Exploratory` where a gate determines the result.
- Pass only surviving hypotheses to comparative ranking.

## Step 6 - hierarchical Pramana comparison

- Group evidence into independent, scope-compatible evidence families.
- Detect applicable support and contradiction at the same highest occupied grade. Do not cancel the conflict numerically; return `Unresolved` or `Escalate` unless scope or dependence analysis removes one side.
- Construct `V(H) = [S5-C5, S4-C4, S3-C3, S2-C2, S1-C1]` for each survivor.
- Compare vectors lexicographically from Grade 5 to Grade 1.
- Record the first differing grade as decisive.
- Do not sum grades or allow lower-grade quantity to override higher-grade evidence.

## Step 7 - tiebreaking and verdict

- If vectors differ, the leading hypothesis is `Provisionally_supported` unless a gate or unresolved decisive critique prevents it.
- If vectors are equal, compare Vyapti scope and path validity.
- If still equal, compare substantive Tarka resolution.
- If still equal, return `Unresolved`; never force a winner.
- Use `Escalate` when high-grade evidence or scope conflict requires human arbitration.

## Step 8 - discriminating experiment

For unresolved hypotheses, propose a test whose possible outcomes distinguish them. Each plan must identify competing predictions, variables, controls, measurements, falsification criteria, required approvals, and PUDA target capabilities. Execution remains `not_authorized`.

## Step 9 - report and feedback

- Return verdicts, pairwise comparisons, evidence vectors, traces, and open evidence gaps.
- The human may approve testing, request revision, add evidence through the extractor, or end the cycle.
- New results enter a child snapshot; they never modify the snapshot used for the current decision.

## Bounded iteration

One cycle contains one critique and one defense per hypothesis. Further revision requires a new cycle referencing the prior trace. This avoids hidden loops and preserves role context.
