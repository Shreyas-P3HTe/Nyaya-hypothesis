# Proponent

## Role
Generates candidate hypotheses and defends them against the Opponent's critique. Combines an LLM-based idea-generation agent with a human-scientist input channel.

## Components

### LLM-Based Idea Generation Agent
- Consumes the Inference channel of the Knowledge Pool (literature, vector maps, knowledge graphs, Vyapti causal maps).
- Produces candidate hypotheses as structured objects (see `schemas/hypothesis-schema.md`), each containing:
  - `pratijna` (claim) -- the hypothesis statement
  - `hetu` (reason) -- the causal or logical justification
  - `drshtanta` (example) -- a supporting analogy, precedent, or prior case
  - list-valued `vyapti_links` resolving only to promoted, projection-eligible `VYP-...` causal edges
  - a proposed `mechanism`, measurable `predictions`, explicit uncertainty, and `evidence_gaps`
- Must cite at least one Knowledge Pool source per hypothesis.

### Human Scientist Input
- Human can submit a hypothesis directly, bypassing LLM generation.
- Human can edit, merge, or discard LLM-generated candidates before they proceed to the Opponent.
- Human input is tagged `source: human` vs. `source: llm` for downstream evaluation (see `evaluation.md`).

## Defense Behavior (Workflow Step 4)
When challenged by the Opponent, the Proponent must respond with one of:

1. **Reinforce** -- provide additional evidence or a stronger `hetu` for the original claim.
2. **Narrow** -- add `scope_conditions` that exclude the counterexample raised by the Opponent.
3. **Revise** -- modify the hypothesis claim itself in light of the critique.
4. **Concede** -- withdraw the hypothesis if the critique is decisive.

The Proponent may not simply repeat the original claim without new support -- this is treated as a failed defense and routed to `Rejected`.

## Constraints

- Every competitively ranked hypothesis must reference at least one promoted, projection-eligible causal edge through `vyapti_links`. Falsifiable ungrounded ideas may be retained as `Exploratory` but cannot receive `Provisionally_supported`.
- Hypotheses must be falsifiable: each must specify, even briefly, what observation would count against it.
- Pramana grades may be copied only when recorded in the permitted inputs. Type determines grade under the frozen policy; the Proponent must not infer or alter either.
