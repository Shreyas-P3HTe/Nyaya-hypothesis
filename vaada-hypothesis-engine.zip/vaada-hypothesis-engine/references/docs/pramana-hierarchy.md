# Pramana Hierarchy

## Purpose

Pramana type directly determines evidential strength. The Judge applies this hierarchy as an ordinal precedence rule, not as a weighted average. Evidence retains its recorded type and grade throughout a frozen Vaada cycle.

## Fixed hierarchy

| Grade | Pramana type | Operational meaning |
|---:|---|---|
| 5 | Pratyaksha - direct experimental | Direct, claim-specific experimental observation produced with a traceable method and result artifact |
| 4 | Anumana - strong causal inference | Strong inference grounded in projection-eligible causal relations, a documented mechanism, and closely applicable evidence |
| 3 | Anumana - indirect empirical | Proxy characterization or simulation relevant to the claim but not a direct test |
| 2 | Upamana - analogy | Evidence from a related but materially distinct system |
| 1 | Shabda - testimony | Traceable literature or expert testimony not independently established within the permitted map |
| 0 | Unsupported | No traceable admissible evidence |

The mapping is fixed by `../evaluation-policy.yaml`. The Judge may copy a recorded grade but may not upgrade, downgrade, average, or invent one during a cycle.

## Hierarchical precedence

1. Compare Grade 5 evidence before considering any lower grade.
2. If Grade 5 does not distinguish the hypotheses, compare Grade 4, then Grade 3, Grade 2, and Grade 1.
3. Any quantity of lower-grade evidence cannot override one applicable higher-grade item.
4. A higher-grade contradiction defeats lower-grade support when the evidence addresses the same claim and scope.
5. Equal-grade conflict remains unresolved unless Vyapti scope validity or Tarka resolution distinguishes the hypotheses.
6. Grade 0 does not contribute support. A hypothesis supported only by Grade 0 is `Exploratory` or `Revise`, never `Provisionally_supported`.

## Evidence vector

First detect whether the highest occupied grade for a hypothesis contains both supporting and contradicting evidence families. Do not cancel that conflict numerically; return `Unresolved` or `Escalate` unless scope or dependence analysis removes one side.

For conflict-free admissible evidence, construct:

```text
V(H) = [S5-C5, S4-C4, S3-C3, S2-C2, S1-C1]
```

`Sg` and `Cg` are counts of independent, scope-compatible supporting and contradicting evidence families at grade `g`. Compare vectors lexicographically from Grade 5 downward only after same-grade conflicts are resolved or explicitly removed by scope and dependence checks. Record the first grade at which the vectors differ as the `decisive_grade`.

## Independence and scope

- Count one evidence family once, even when a paper reports repeated measurements, several figures, or derivative analyses.
- Treat independent replications as separate families only when independence is documented.
- Exclude out-of-scope evidence from the vector and retain it as qualifying evidence.
- When an evidence family's independence is unresolved, count it once and record the uncertainty.

## Conflict handling

- Higher-grade contradiction over lower-grade support: reject or revise the contradicted hypothesis, subject to scope validation.
- Same-grade support and contradiction: return `Unresolved` unless a valid tiebreaker applies.
- Conflicting Grade 4 or Grade 5 evidence without a valid tiebreaker: `Escalate` or propose a discriminating experiment.

Pramana ranks evidence. It does not remove the need for Vyapti scope checks, fallacy checks, or falsifiability.
