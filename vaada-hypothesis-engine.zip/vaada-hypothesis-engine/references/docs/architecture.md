# Architecture

## Overview

The system has three layers: a Knowledge Pool, the Vaada reasoning engine, and a human-facing interface. The Knowledge Pool provides frozen, evidence-backed causal-map snapshots. The Vaada engine generates, critiques, compares, and judges hypotheses. The human scientist supplies the research question, approves experiments, and receives traceable outcomes.

## Knowledge Pool

The inference channel contains literature-derived claims, retrieved passages, knowledge structures, and synthesized Vyapti edges. The direct-evidence channel contains proxy characterizations, simulations, and benchside experiments. Every object retains provenance, scope, access status, and an immutable identifier.

## Vaada Engine

- **Proponent:** produces falsifiable `pratijna`, `hetu`, and `drshtanta` objects grounded in projection-eligible `VYP-...` edges.
- **Opponent:** applies Tarka, Hetvabhasa, counterfactual critique, scope checks, and duplication checks.
- **Judge:** applies validity gates, compares Pramana evidence hierarchically, uses only permitted Vyapti and Tarka tiebreakers, and refuses to force a winner.

Pramana type directly determines evidential strength. Hypotheses are compared from Grade 5 downward. If the evidence and permitted tiebreakers do not distinguish them, the scientific result is `Unresolved`.

## Human and PUDA boundary

The human scientist may edit hypotheses, resolve escalations, or approve a discriminating experiment. Vaada emits only a non-authorized experiment plan. PUDA validates and executes an approved plan against equipment capabilities and safety constraints. Results return through the extractor into a new immutable snapshot.

## Data flow

```text
research question + frozen snapshot
        -> Proponent
        -> Opponent
        -> Proponent defense
        -> Judge gates
        -> hierarchical Pramana comparison
        -> provisional support OR unresolved comparison
        -> human approval
        -> optional PUDA experiment
        -> extractor
        -> child snapshot
```

The architecture distinguishes being best supported now from being proven true. A provisional leader may be displaced when stronger evidence enters a later snapshot.
