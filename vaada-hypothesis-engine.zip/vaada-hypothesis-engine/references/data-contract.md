# Extractor and laboratory boundary

The only scientific knowledge input is a frozen graph snapshot with a recorded SHA-256. The engine never mutates that file.

Use `schemas/knowledge-map-snapshot.schema.json` for snapshots. Resolve every variable, claim, synthesized `VYP-...` edge, source, evidence item, and promotion decision before beginning a cycle. A hypothesis may use a causal edge as Vyapti grounding only when the frozen snapshot records the edge as `projection_eligible: true` and its promotion decision is `promoted`. Existing legacy graphs must first be represented through this snapshot contract without altering their source records.

Use `evaluation-policy.yaml` as the frozen comparison policy. Pramana type determines evidence strength. The Judge compares hypotheses hierarchically from Grade 5 to Grade 1 and must not invent weights, thresholds, or grades.

When Vaada recommends a test, emit an object conforming to `schemas/experiment-plan.schema.json` with `execution_status: not_authorized`. A PUDA equipment skill may translate it only after explicit human approval. Return raw results to the extractor as experimental or simulation candidates; do not inject them into the active Vaada run or upgrade their evidence grade in place.

This creates an auditable sequence:

```text
snapshot N -> hypothesis/debate/comparison -> approved plan -> PUDA run
           -> hashed result artifact -> extractor staging/reconciliation/promotion
           -> snapshot N+1 -> later Vaada cycle
```
