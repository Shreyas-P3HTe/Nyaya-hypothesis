---
name: causal-knowledge-extractor
description: Ingest local PDFs, experimental results, simulations, internal reports, and unpublished datasets; extract atomic source-grounded causal claims; reconcile variables; and prepare immutable Nyaya knowledge-map snapshots. Use for literature extraction, evidence registration, causal-map maintenance, conflict-preserving updates, or preparing a frozen map for Vaada. Do not use for hypothesis generation or debate.
---

# Nyaya Knowledge Extractor

Operate as a single extraction and knowledge-mapping role. Do not invoke or imitate a Proponent, Opponent, or Judge. Use the host's local filesystem and shell capabilities as needed, but keep PDFs, full text, datasets, and generated knowledge local.

Read these references completely before acting:

- `references/causal-extraction-contract.md` for atomic claim extraction;
- `references/knowledge-mapping.md` for incremental updates and source classes;
- `references/schemas/causal-map-schema.md` for the canonical object model;
- the applicable JSON Schemas under `references/schemas/`.

For PDF work, also read `references/docs/pdf-ingestion.md`.

## Workflow

1. Freeze the permitted local input paths. Never inspect adjacent files implicitly.
2. Inventory and SHA-256 hash every source without modifying it. Detect duplicates, corrupt or encrypted PDFs, non-PDF archive members, and insufficient text.
3. Preserve page-aware passages and quarantine OCR-required documents.
4. Extract one cause-effect pair per candidate. Preserve relation type, direction, polarity, directness, mechanism, temporal order, context, boundary conditions, uncertainty, and evidence class.
5. Validate every citation against the exact local passage or data artifact. A literature evidence span must occur verbatim in its passage. A data locator must resolve to a local artifact whose hash matches.
6. Reconcile each local cause and effect with a stable existing variable ID, or propose a distinct new variable. Never merge on name similarity alone.
7. Preserve each candidate, reconciliation, and human promotion decision as a separate append-only record.
8. Synthesize compatible reviewed claims into versioned `VYP-...` causal edges without discarding contradictions or scope.
9. Assign Pramana type and its fixed corresponding grade from recorded evidence; never grade by rhetoric or citation count.
10. Promote, reject, or hold an edge only with explicit human authority. Promotion means eligible under recorded scope, not universally true. Record `projection_eligible` explicitly.
11. Produce a new immutable v2 snapshot referencing the parent snapshot hash. Never edit an earlier snapshot.

Only explicitly causal or mechanistic relations may be projected as causal roads. Preserve correlations, predictions, hypotheses, contradictions, and nulls as searchable non-causal knowledge.

Stop on missing provenance, unresolved variables, schema failures, causal promotion, access-control ambiguity, or any need to invent or silently repair scientific content. Never disclose confidential or restricted evidence in a less restricted output.

Return a concise trace listing input hashes, candidates, reconciliations, synthesized edges, Pramana mappings, promotion decisions, snapshot ID and hash, parent hash, projection-eligible edges, non-causal retained records, unresolved items, and access restrictions.
