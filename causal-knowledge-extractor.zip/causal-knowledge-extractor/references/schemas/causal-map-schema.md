# Causal Literature Map Schema


## 1. Purpose

This document defines a schema for building an evidence-backed causal knowledge graph from scholarly literature and empirical, observational, qualitative, and computational data.

The schema must support:

- extraction of causal claims from exact source passages;
- one cause with multiple effects;
- multiple causes of one effect;
- direct, indirect, mediated, moderated, and confounded relations;
- positive, negative, null, non-monotonic, and context-dependent effects;
- supporting, contradicting, and qualifying evidence;
- system-, population-, intervention-, observation-, environment-, and time-specific scope;
- aggregation of multiple literature claims into versioned causal-map edges;
- traceability from every synthesized edge to its source documents;
- later export of scoped subgraphs for causal inference, study design, decision support, or intervention planning.

The schema does not assume that causal language in a paper establishes causality. It records what was claimed, how it was supported, and how the claim was subsequently evaluated.

## 2. Design principles

1. **Claims are not facts.** An extracted causal claim is an assertion made by a source.
2. **Every claim is traceable.** Each claim must point to an exact document passage.
3. **Each edge is atomic.** A causal edge normally connects one cause variable to one effect variable.
4. **One-to-many relations use multiple edges.** One cause may have any number of outgoing causal edges.
5. **Related claims may be grouped.** Claims from the same passage or study may share a `claim_group_id` without being collapsed into one edge.
6. **Scope is mandatory.** A relation is valid only under its recorded system, population, intervention, observation, environmental, and temporal conditions.
7. **Direct and indirect effects are distinct.** A causal path must not be silently converted into a direct edge.
8. **Contradictions are preserved.** Conflicting evidence is represented, not averaged away automatically.
9. **Extraction confidence is not scientific confidence.** These quantities must be stored separately.
10. **Synthesized edges are versioned.** New evidence produces a new synthesis version while preserving the underlying claims.
11. **The core is domain-neutral.** Domain-specific ontologies and attributes extend the schema without changing its causal, evidential, or provenance structure.

## 3. Conceptual layers

### 3.1 Source layer

Stores documents, passages, tables, figures, datasets, and bibliographic provenance.

### 3.2 Assertion layer

Stores immutable claims extracted from individual sources. Each claim records a cause, an effect, author language, scope, proposed mechanism, and linked evidence.

### 3.3 Evidence layer

Stores the study design, measurements, statistics, directness, methodological quality, limitations, and reproducibility of the evidence used by a claim.

### 3.4 Synthesis layer

Aggregates compatible claims into versioned causal edges while retaining supporting, contradicting, and qualifying evidence.

### 3.5 Projection layer

Materializes simplified `CAUSES` relationships between variables for fast navigation and path queries. Every projected relationship points back to the complete synthesized edge.

## 4. Core object model

| Object | Purpose |
|---|---|
| `source_document` | Paper, preprint, thesis, patent, dataset, or internal report |
| `source_passage` | Exact location from which a claim was extracted |
| `variable` | Canonical cause, effect, mediator, moderator, confounder, or context variable |
| `studied_system` | Population, organism, organization, technology, ecosystem, physical system, or other subject of study |
| `study` | Experimental, computational, or observational investigation |
| `evidence_item` | A result supporting, contradicting, or qualifying a claim |
| `evidence_family` | Independence group used to prevent repeated results from being counted as replications |
| `causal_claim` | One source-specific cause-effect assertion |
| `claim_group` | Related atomic claims originating from the same passage, figure, or study |
| `mechanism` | Proposed or observed physical, biological, social, economic, computational, or other domain pathway |
| `causal_edge` | Versioned synthesis of claims about one cause-effect pair |
| `causal_path` | Ordered chain of two or more causal edges |
| `context` | Boundary conditions under which a claim or edge applies |
| `extraction_record` | Extraction model, prompt, confidence, and validation metadata |
| `review_record` | Human review, correction, approval, or rejection |
| `promotion_decision` | Append-only human authorization of a synthesized edge for scoped projection |

## 5. Cardinality and multiplicity rules

### 5.1 One cause, multiple effects

A single cause is represented by one `variable` object connected to multiple independent claims or edges.

```text
Intervention intensity
    -> Response magnitude
    -> Response time
    -> Outcome variability
    -> Resource use
```

Each arrow is stored as a separate `causal_claim` and, after synthesis, a separate `causal_edge`.

### 5.2 Multiple causes, one effect

Independent causes use separate edges:

```text
Intervention intensity -> Outcome variability
Environmental exposure -> Outcome variability
Baseline state         -> Outcome variability
```

If the effect depends on a joint cause, exposure, intervention, or interaction, the combination must be represented explicitly rather than as independent causal effects.

```yaml
cause_set:
  combination_type: interaction
  members:
    - variable_id: VAR-INTERVENTION-INTENSITY
    - variable_id: VAR-ENVIRONMENTAL-EXPOSURE
```

### 5.3 Multiple effects reported by one study

Create one atomic claim per cause-effect pair and connect the claims through a common `claim_group_id` and `study_id`.

### 5.4 Direct and mediated effects

For the chain:

```text
Intervention intensity -> Intermediate response -> Response stability -> Outcome variability
```

store three atomic edges and one `causal_path`. Add a direct `Intervention intensity -> Outcome variability` edge only if the source or analysis supports a direct or total effect.

## 6. Identifier conventions

Identifiers must be stable and globally unique within the project.

| Object | Prefix | Example |
|---|---|---|
| Document | `DOC` | `DOC-000001` |
| DOI | `DOI` | `doi.org/10.1353/lib.2025.a961193`|
| Passage | `PAS` | `PAS-000001` |
| Variable | `VAR` | `VAR-INTERVENTION-INTENSITY` |
| Studied system | `SYS` | `SYS-000001` |
| Study | `STD` | `STD-000001` |
| Evidence | `EVD` | `EVD-000001` |
| Evidence family | `EFAM` | `EFAM-000001` |
| Claim | `CLM` | `CLM-000001` |
| Claim group | `CGR` | `CGR-000001` |
| Mechanism | `MEC` | `MEC-000001` |
| Causal edge | `VYP` | `VYP-000001` |
| Causal path | `PTH` | `PTH-000001` |
| Context | `CTX` | `CTX-000001` |
| Extraction record | `EXT` | `EXT-000001` |
| Review record | `REV` | `REV-000001` |
| Promotion decision | `PRM` | `PRM-000001` |

Identifiers must never encode mutable information such as confidence, status, or graph position.

## 7. Source document schema

```yaml
source_document:
  document_id: DOC-000001
  title: ""
  authors: []
  publication_year: null
  journal_or_repository: ""
  doi: null
  url: null
  document_type: journal_article
  peer_reviewed: true
  retraction_status: not_retracted
  language: en
  license: null
  ingestion_timestamp: ""
  content_hash: ""
  local_reference: null
```

### Controlled vocabulary: `document_type`

- `journal_article`
- `conference_paper`
- `preprint`
- `review_article`
- `systematic_review`
- `meta_analysis`
- `book_or_chapter`
- `thesis`
- `patent`
- `dataset`
- `internal_report`
- `policy_report`
- `technical_report`
- `white_paper`
- `standard`
- `other`

## 8. Source passage schema

```yaml
source_passage:
  passage_id: PAS-000001
  document_id: DOC-000001
  page_number: 7
  section_path:
    - Results
    - Electrical characterization
  paragraph_number: 3
  sentence_start: 42
  sentence_end: 43
  text: ""
  surrounding_context: ""
  table_reference: null
  figure_reference: Figure 4b
  supplementary_reference: null
```

The passage must contain, or be directly adjacent to, the language used to construct the extracted claim.

## 9. Variable schema

```yaml
variable:
  variable_id: VAR-INTERVENTION-INTENSITY
  canonical_name: intervention_intensity
  display_name: Intervention intensity
  reported_names:
    - intervention level
    - exposure intensity
  ontology_ids: []
  quantity_type: continuous
  default_unit: null
  domain_category: intervention
  description: "Magnitude or level of the intervention or exposure"
```

### Controlled vocabulary: `quantity_type`

- `continuous`
- `discrete`
- `categorical`
- `binary`
- `ordinal`
- `time_series`
- `latent`
- `unknown`

### Controlled vocabulary: `domain_category`

- `exposure`
- `intervention`
- `treatment`
- `behavior`
- `biological`
- `chemical`
- `physical`
- `environmental`
- `social`
- `economic`
- `organizational`
- `policy`
- `computational`
- `technical`
- `measurement`
- `outcome`
- `other`

The role of a variable is claim-specific and must not be permanently assigned to the variable object.

## 10. Studied system schema

```yaml
studied_system:
  studied_system_id: SYS-000001
  canonical_name: Target system or population
  system_type: population
  description: "The entities or system to which the study and claim apply"
  parent_system_id: null
  component_ids: []
  attributes: {}
  ontology_ids: []
```

### Controlled vocabulary: `system_type`

- `population`
- `individual`
- `organism`
- `organization`
- `institution`
- `society`
- `economy`
- `ecosystem`
- `physical_system`
- `chemical_system`
- `biological_system`
- `technical_system`
- `software_system`
- `model_system`
- `other`

### 10.1 Domain extensions

Domain-specific information must be introduced through `ontology_ids`, typed entries in `attributes`, and optional extension objects. Domain extensions may add vocabulary and validation rules, but must not change the meanings of core objects such as `causal_claim`, `evidence_item`, `context`, or `causal_edge`.

This allows the same core graph to represent causal knowledge in fields such as biology, medicine, engineering, economics, policy, social science, environmental science, organizational research, and computing.

## 11. Context schema

```yaml
context:
  context_id: CTX-000001
  studied_system_ids:
    - SYS-000001
  domain_conditions: {}
  cause_or_exposure_conditions:
    intervention_intensity: [0.2, 0.8]
    exposure_duration: null
  observation_conditions: {}
  measurement_conditions:
    measurement_method: ""
    instrument_or_assessment: null
  environmental_conditions:
    location: null
    ambient_conditions: {}
  spatial_scope: null
  temporal_scope:
    start: null
    end: null
    time_unit: null
  population_scope:
    inclusion_criteria: []
    exclusion_criteria: []
  explicit_exclusions: []
  free_text_conditions: []
```

Unknown conditions must remain `null`; they must not be filled using assumptions.

## 12. Study schema

```yaml
study:
  study_id: STD-000001
  document_id: DOC-000001
  study_type: controlled_experiment
  objective: ""
  studied_system_ids:
    - SYS-000001
  context_id: CTX-000001
  sample_size: null
  number_of_independent_groups_or_sites: null
  randomization_reported: null
  blinding_reported: null
  controls_reported: true
  data_available: false
  code_available: false
  preregistered: false
```

### Controlled vocabulary: `study_type`

- `randomized_experiment`
- `controlled_experiment`
- `natural_experiment`
- `quasi_experiment`
- `observational_study`
- `longitudinal_study`
- `cross_sectional_study`
- `qualitative_study`
- `mixed_methods_study`
- `causal_inference_analysis`
- `simulation`
- `mechanistic_characterization`
- `proxy_characterization`
- `case_study`
- `systematic_review`
- `meta_analysis`
- `review_synthesis`
- `expert_interpretation`

## 13. Evidence item schema

```yaml
evidence_item:
  evidence_id: EVD-000001
  evidence_family_id: EFAM-000001
  study_id: STD-000001
  passage_ids:
    - PAS-000001
  evidence_type: controlled_experiment
  evidence_role: supports
  pramana:
    type: pratyaksha_direct_experimental
    grade: 5
  cause_or_exposure:
    variable_id: VAR-INTERVENTION-INTENSITY
    levels: [0.2, 0.4, 0.6, 0.8]
    unit: normalized_unit
  outcome:
    variable_id: VAR-OUTCOME-VARIABILITY
    metric: standard_deviation
    unit: normalized_unit
  statistics:
    sample_size: 60
    effect_estimate: -0.4301
    effect_metric: standardized_effect
    confidence_interval: null
    standard_error: null
    p_value: 0.0283
    adjusted_p_value: null
    uncertainty_reported: true
  quality_dimensions:
    directness: 4
    methodological_rigor: 3
    reproducibility: 2
    claim_relevance: 5
    causal_identifiability: 3
    reporting_completeness: 4
  independent_replication: false
  limitations:
    - "Limited number of independent settings"
  data_reference: null
  code_reference: null
```

### Controlled vocabulary: `evidence_role`

- `supports`
- `contradicts`
- `qualifies`
- `defines_boundary`
- `inconclusive`

Quality dimensions use an integer scale from 0 to 5 and remain separate extraction diagnostics. They do not alter the fixed Pramana type-grade mapping and are not combined into a hypothesis-winning score.

`evidence_family_id` groups results that are not independent. Repeated measurements, figures, analyses, or publications from the same underlying experiment remain one family unless independence is documented.

## 14. Causal claim schema

A causal claim is an atomic, source-specific assertion connecting one cause to one effect.

```yaml
causal_claim:
  claim_id: CLM-000001
  claim_group_id: CGR-000001
  document_id: DOC-000001
  passage_ids:
    - PAS-000001

  cause:
    variable_id: VAR-INTERVENTION-INTENSITY
    reported_name: intervention intensity
    value_or_range: [0.2, 0.8]
    unit: normalized_unit

  effect:
    variable_id: VAR-OUTCOME-VARIABILITY
    reported_name: outcome variability
    value_or_range: null
    unit: normalized_unit

  relation:
    relation_type: causal
    polarity: negative
    functional_form: monotonic
    directness: indirect
    temporal_order: cause_precedes_effect
    reversible: unknown

  author_language:
    causal_cue: reduces
    assertion_strength: supports
    negated: false
    speculative: false

  mechanism:
    description: >
      Higher intervention intensity changes an intermediate response,
      thereby reducing variability in the observed outcome.
    mediator_variable_ids:
      - VAR-INTERMEDIATE-RESPONSE
    moderator_variable_ids: []
    confounder_variable_ids: []

  context_id: CTX-000001
  evidence_ids:
    - EVD-000001
  extraction_record_id: EXT-000001
  review_status: pending
```

### Controlled vocabulary: `relation_type`

- `causal`
- `direct_causal`
- `mediated_causal`
- `moderated_causal`
- `mechanistic`
- `correlational`
- `associative`
- `predictive`
- `null_effect`
- `contradictory`
- `hypothesized`

### Controlled vocabulary: `polarity`

- `positive`
- `negative`
- `no_effect`
- `non_monotonic`
- `threshold`
- `u_shaped`
- `inverted_u`
- `bidirectional`
- `context_dependent`
- `unknown`

### Controlled vocabulary: `functional_form`

- `linear`
- `monotonic`
- `non_monotonic`
- `threshold`
- `saturating`
- `exponential`
- `power_law`
- `categorical_transition`
- `unknown`

### Controlled vocabulary: `assertion_strength`

- `demonstrates`
- `supports`
- `suggests`
- `consistent_with`
- `hypothesizes`
- `speculates`
- `does_not_support`

## 15. Claim group schema

Use a claim group when a passage, figure, or study reports several atomic effects of the same cause, exposure, or intervention.

```yaml
claim_group:
  claim_group_id: CGR-000001
  document_id: DOC-000001
  study_id: STD-000001
  passage_ids:
    - PAS-000001
  grouping_reason: common_cause_multiple_effects
  common_cause_variable_ids:
    - VAR-INTERVENTION-INTENSITY
  claim_ids:
    - CLM-000001
    - CLM-000002
    - CLM-000003
    - CLM-000004
```

### Controlled vocabulary: `grouping_reason`

- `common_cause_multiple_effects`
- `common_mechanism`
- `common_figure_or_table`
- `joint_cause_or_intervention`
- `multivariate_model`
- `other`

## 16. Causal edge schema

A causal edge synthesizes compatible claims concerning one canonical cause-effect pair.

```yaml
causal_edge:
  edge_id: VYP-000001
  edge_version: 1
  source_variable_id: VAR-INTERVENTION-INTENSITY
  target_variable_id: VAR-OUTCOME-VARIABILITY

  relation:
    relation_type: mediated_causal
    polarity: negative
    functional_form: monotonic
    directness: indirect

  mechanism_ids:
    - MEC-000001
  context_ids:
    - CTX-000001

  supporting_claim_ids:
    - CLM-000001
  contradicting_claim_ids: []
  qualifying_claim_ids: []

  evidence_summary:
    supporting_evidence_count: 1
    contradicting_evidence_count: 0
    independent_document_count: 1
    independent_source_group_count: null
    replication_count: 0

  pramana:
    type: anumana_strong_causal_inference
    grade: 4

  invariance_evidence:
    environments:
      - Setting_A
      - Setting_B
    effect_estimates:
      - environment: Setting_A
        estimate: -0.6703
        p_value: 0.00013
      - environment: Setting_B
        estimate: -0.4301
        p_value: 0.0283
    direction_consistency: 1.0
    sign_stability: 0.995
    minimum_absolute_effect: 0.4301
    combined_p_value: 0.00005

  epistemic_status:
    author_causal_claim_present: true
    intervention_supported: true
    causal_identification_supported: false
    mechanism_supported: partial
    invariance_supported: true
    independently_replicated: false

  synthesis:
    status: strong_candidate
    confidence: 0.78
    uncertainty: moderate
    scoring_rule_version: causal-synthesis-v0.1
    generated_at: ""
    generated_by: ""
    human_validated: false

  projection_eligible: false

  previous_version_id: null
```

### Controlled vocabulary: `status`

- `extracted_candidate`
- `weak_candidate`
- `directional_candidate`
- `strong_candidate`
- `contested`
- `falsified`
- `accepted_with_scope`
- `deprecated`

The `confidence` field is a synthesis output. It must not be copied from LLM extraction confidence.

Pramana type determines grade under the versioned comparison policy:

- `pratyaksha_direct_experimental` -> 5
- `anumana_strong_causal_inference` -> 4
- `anumana_indirect_empirical` -> 3
- `upamana_analogy` -> 2
- `shabda_testimony` -> 1

`projection_eligible` is false by default. It becomes true only through an explicit promotion decision for a causal or mechanistic relation under its recorded scope. Grade alone never makes an edge causal or projection-eligible.

### 16.1 Mechanism schema

Mechanisms are stored separately so the same proposed pathway can be connected to multiple claims or edges without duplicating its description.

```yaml
mechanism:
  mechanism_id: MEC-000001
  canonical_name: response_mediated_variability_reduction
  description: >
    Increased intervention intensity changes an intermediate response,
    thereby reducing variability in the observed outcome.
  ordered_variable_ids:
    - VAR-INTERVENTION-INTENSITY
    - VAR-INTERMEDIATE-RESPONSE
    - VAR-OUTCOME-VARIABILITY
  status: proposed
  passage_ids:
    - PAS-000001
  evidence_ids:
    - EVD-000001
```

Controlled values for `status` are `proposed`, `partially_observed`, `observed`, `validated`, `contested`, and `falsified`.

### 16.2 Promotion decision schema

```yaml
promotion_decision:
  decision_id: PRM-000001
  object_type: causal_edge
  object_id: VYP-000001
  decision: promoted
  projection_eligible: true
  authorized_by: human-reviewer-id
  decided_at: ""
  rationale: Eligible as a scoped causal edge under the reviewed evidence.
```

Promotion decisions are append-only. Controlled decisions are `promoted`, `rejected`, and `hold`. Only a promoted causal edge may record `projection_eligible: true`.

## 17. Causal path schema

```yaml
causal_path:
  path_id: PTH-000001
  source_variable_id: VAR-INTERVENTION-INTENSITY
  target_variable_id: VAR-OUTCOME-VARIABILITY
  ordered_edge_ids:
    - VYP-INTERVENTION-INTERMEDIATE-RESPONSE
    - VYP-INTERMEDIATE-RESPONSE-STABILITY
    - VYP-RESPONSE-STABILITY-OUTCOME-VARIABILITY
  path_type: mediated
  context_ids:
    - CTX-000001
  path_status: proposed
  supporting_evidence_ids: []
```

### Controlled vocabulary: `path_type`

- `mediated`
- `mechanistic`
- `feedback_time_indexed`
- `alternative_mechanism`
- `confounding_path`

## 18. Extraction record schema

```yaml
extraction_record:
  extraction_record_id: EXT-000001
  object_type: causal_claim
  object_id: CLM-000001
  extractor_type: llm
  model_name: ""
  model_version: ""
  prompt_version: causal-extraction-v0.1
  extraction_timestamp: ""
  extraction_confidence: 0.91
  grounding_checks:
    cause_grounded_in_passage: true
    effect_grounded_in_passage: true
    relation_grounded_in_passage: true
    polarity_grounded_in_passage: true
    scope_grounded_in_passage: partial
    citation_resolved: true
  requires_human_review: true
  validation_status: machine_validated
```

### Controlled vocabulary: `validation_status`

- `unvalidated`
- `machine_validated`
- `human_verified`
- `human_corrected`
- `rejected`

## 19. Review record schema

```yaml
review_record:
  review_id: REV-000001
  object_type: causal_claim
  object_id: CLM-000001
  reviewer_id: ""
  review_timestamp: ""
  decision: corrected
  corrected_fields:
    - relation.directness
  rationale: "The passage supports a mediated rather than direct effect."
  previous_value:
    relation.directness: direct
  updated_value:
    relation.directness: indirect
```

## 20. Graph representation

### 20.1 Assertion graph

```text
(Document)-[:HAS_PASSAGE]->(Passage)
(Passage)-[:ASSERTS]->(CausalClaim)
(CausalClaim)-[:HAS_CAUSE]->(Variable)
(CausalClaim)-[:HAS_EFFECT]->(Variable)
(CausalClaim)-[:HAS_MECHANISM]->(Mechanism)
(CausalClaim)-[:APPLIES_UNDER]->(Context)
(Evidence)-[:SUPPORTS|CONTRADICTS|QUALIFIES]->(CausalClaim)
```

### 20.2 Synthesis graph

```text
(Variable)-[:SOURCE_OF]->(CausalEdge)
(CausalEdge)-[:TARGETS]->(Variable)
(CausalEdge)-[:HAS_MECHANISM]->(Mechanism)
(CausalEdge)-[:DERIVED_FROM]->(CausalClaim)
(CausalEdge)-[:APPLIES_UNDER]->(Context)
(CausalEdge)-[:SUPERSEDES]->(CausalEdge)
```

### 20.3 Navigational projection

```text
(Variable)-[:CAUSES {
  edge_id,
  edge_version,
  polarity,
  relation_type,
  status,
  confidence,
  pramana_grade,
  projection_eligible
}]->(Variable)
```

The projected `CAUSES` relationship is derived data and must be rebuildable from the corresponding `causal_edge` object.

## 21. Example: one cause with multiple effects

```yaml
claim_group:
  claim_group_id: CGR-000010
  document_id: DOC-000010
  study_id: STD-000010
  grouping_reason: common_cause_multiple_effects
  common_cause_variable_ids:
    - VAR-INTERVENTION-INTENSITY
  claim_ids:
    - CLM-000101
    - CLM-000102
    - CLM-000103
    - CLM-000104

causal_claims:
  - claim_id: CLM-000101
    cause_variable_id: VAR-INTERVENTION-INTENSITY
    effect_variable_id: VAR-RESPONSE-MAGNITUDE
    polarity: positive

  - claim_id: CLM-000102
    cause_variable_id: VAR-INTERVENTION-INTENSITY
    effect_variable_id: VAR-RESPONSE-TIME
    polarity: negative

  - claim_id: CLM-000103
    cause_variable_id: VAR-INTERVENTION-INTENSITY
    effect_variable_id: VAR-OUTCOME-VARIABILITY
    polarity: negative

  - claim_id: CLM-000104
    cause_variable_id: VAR-INTERVENTION-INTENSITY
    effect_variable_id: VAR-RESOURCE-USE
    polarity: positive
```

This is an abbreviated projection of the four complete `causal_claim` objects. The complete records must still contain the passage, context, evidence, author-language, and extraction fields defined in Section 14. These claims share provenance but remain independently assessable.

## 22. Mandatory validation rules

1. Every `causal_claim` must reference at least one valid passage.
2. Every passage must reference a valid document.
3. Cause and effect must resolve to canonical variables.
4. Cause and effect cannot be identical unless the claim is explicitly time-indexed.
5. Each atomic claim must contain exactly one primary cause and one primary effect.
6. Multiple effects must be separated into multiple claims.
7. Joint causes must use an explicit `cause_set` or interaction representation.
8. Correlational language must not be promoted automatically to a causal relation.
9. Negation and speculative wording must be preserved.
10. Unknown values must remain `null` rather than being inferred silently.
11. Every synthesized edge must reference at least one claim.
12. Supporting and contradicting claims must not be stored in the same list.
13. Direct, indirect, and total effects must not be treated as interchangeable.
14. Contexts must be checked for compatibility before claims are aggregated.
15. Effect estimates with incompatible units or estimands must not be averaged.
16. Multiple results from the same study must not be counted as independent replication.
17. Extraction confidence must not determine causal confidence.
18. Every synthesis must record its rule version and previous edge version.
19. A projected `CAUSES` relationship must point to a valid synthesized edge.
20. Human corrections must be recorded through a review record rather than silently overwriting provenance.
21. Pramana type and grade must match the versioned fixed mapping.
22. Projection eligibility requires an explicit promotion decision.
23. Correlational, associative, predictive, null, contradictory, or hypothesized records cannot be projection-eligible.

## 23. Aggregation rules

Claims may be considered for the same synthesized edge only when they have compatible:

- canonical cause variable;
- canonical effect variable;
- causal direction;
- effect polarity or explicitly reconcilable polarity;
- effect definition and unit;
- temporal ordering;
- studied system or population;
- major scope conditions;
- cause or exposure and effect or outcome definitions.

When contexts differ materially, create separate scoped edges and optionally connect them through a higher-level relation such as `CONTEXTUAL_VARIANT_OF`.
