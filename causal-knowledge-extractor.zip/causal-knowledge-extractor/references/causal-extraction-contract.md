# Single-pass causal extraction contract

Read `schemas/causal-map-schema.md` and `schemas/knowledge-candidate.schema.json` completely. Use only supplied local source objects and passages or artifacts.

For each candidate:

- Represent exactly one cause and one effect. Split multiple effects and preserve a shared group identifier in an extension field.
- Preserve reported variable names, units, values or ranges, direction, polarity, relation type, directness, temporal order, study/system context, intervention or exposure, population or unit, mechanism, mediators, moderators, confounders, boundary conditions, and uncertainty.
- Distinguish controlled experiments, quasi-experiments, observational causal estimates, mechanistic evidence, author causal interpretations, hypotheses, correlations, contradictions, and null findings.
- Do not promote association, prediction, sequence, or speculation to causation.
- For literature, cite an existing document, page, passage, and short exact evidence span.
- For experimental, simulated, or unpublished evidence, cite the immutable artifact hash and exact run, row, series, table, or record locator.
- Preserve access and publication status. Never describe unpublished or internal evidence as published or independently replicated.
- Never invent text, results, statistics, IDs, citations, variables, or missing conditions.

Output JSONL-compatible candidate objects. Return no record when the source does not support a compliant candidate. The mapping script, not the extractor, assigns stable candidate/source/claim/evidence IDs and controls promotion.
