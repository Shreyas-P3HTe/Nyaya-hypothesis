# Knowledge Pool

## Purpose
Aggregates all raw and structured information the engine can draw on, split into two channels that feed into the Vaada Engine.

## Inference Channel (Anumana Pramana channel)

| Component | Description |
|---|---|
| Literature parsing + RAG | Retrieval-augmented parsing of papers, preprints, and reviews into queryable chunks |
| Web scraper | Supplementary retrieval of recent, non-indexed, or grey-literature sources |
| Vector maps | Embedding-based similarity structure over the corpus, used for retrieval and novelty checks |
| Knowledge graphs | Entity-relation graphs extracted from literature (structural, not necessarily causal) |
| Vyapti causal maps | Directed causal graphs: node = variable/mechanism, edge = claimed causal relation with supporting citation and confidence |

## Direct Evidence Channel (Pratyaksha Pramana channel)

| Component | Description |
|---|---|
| Proxy characterizations | Indirect measurements or surrogate markers relevant to the hypothesis |
| Simulations | Computational or physical models producing predicted outcomes |
| Benchside experiments | Real experimental results, either historical or newly run |

## Vyapti Causal Map -- Structure

A causal map entry should record:

- `source_node` -- variable or mechanism
- `target_node` -- outcome or downstream variable
- `relation_type` -- a controlled value from `schemas/causal-map-schema.md`, preserved without causal promotion
- `pramana_grade` -- fixed by evidence type under the consuming Vaada policy
- `supporting_sources` -- list of literature or data references
- `scope_conditions` -- boundary conditions under which the relation holds (critical for the Vyapti check in `workflow.md` Step 2)
- `projection_eligible` -- true only after explicit promotion of a causal or mechanistic synthesized edge

## Update Policy

- New literature or experimental results are ingested continuously and re-indexed into vector maps and knowledge graphs.
- A synthesized edge becomes projection-eligible only after explicit promotion. Pramana grade alone never converts a correlation, prediction, or hypothesis into a causal edge.
- Rejected hypotheses and their rejection reasons are stored back into the pool to prevent duplicate generation (feeds Opponent's deduplication check).
