# Local PDF ingestion prompt contract

Use only local tools already available to the host. Keep the archive and original PDFs read-only.

## Inventory

- Inspect archive entries without extracting into archive-provided paths.
- Reject absolute paths, traversal paths, links, extreme compression ratios, and over-sized members.
- Identify PDFs by content signature rather than filename.
- Compute SHA-256 while streaming each PDF.
- Assign stable document IDs from content hashes.
- Record duplicates, non-PDFs, corrupt PDFs, encryption, page counts, and embedded metadata.
- Use embedded PDF metadata only and mark the bibliographic match unresolved. Never infer bibliographic identity from filenames.
- doi numbers are valid identifiers - use them whenever available for referencing and traceability 

## Text and passages

- Extract page-aware text using a local PDF text tool.
- Preserve document ID, page number, detected section, passage ID, offsets where practical, extraction method, and quality indicators.
- Detect empty, scanned, or garbled pages and route their documents to an OCR-required queue.
- Do not silently treat failed extraction as evidence.

After text extraction, perform one source-grounded pass under `references/causal-extraction-contract.md`. There is no Proponent, Opponent, or Judge stage in extraction. Validate candidates against the local passage set before preparing a knowledge-map update.

Keep an append-only manifest containing software versions, timestamps, input hashes, prompts used, errors, and resumable stage status. Log per-document failures and continue safely where possible.
