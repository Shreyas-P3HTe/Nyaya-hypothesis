# Incremental knowledge mapping contract

## Boundary

The map is append-only. New inputs never edit an old claim, edge version, or snapshot. Each update creates a candidate, a variable-reconciliation record, any compatible synthesized `VYP-...` edge version, a promotion decision, and then a child snapshot identified by its content and parent hashes.

## Source classes

| Source kind | Required locator | Publication handling |
|---|---|---|
| `published_literature` or `preprint` | Document ID, passage ID, page, exact evidence span | Preserve citation and publication status. |
| `experimental_data` | Immutable artifact path/hash, run or record locator, measurement details | Never call it published or independently replicated. |
| `simulation` | Input/output artifact hashes, run locator, software/configuration provenance | Preserve model assumptions and classify it as simulation evidence. |
| `unpublished_data` or `internal_report` | Artifact path/hash, record locator, custodian, access label | Do not expose confidential values in public exports. |

## Variable reconciliation

For each local cause and effect name, record exactly one decision:

- `reuse`: quantity, unit semantics, system role, and operational definition match an existing variable.
- `create`: the concept is materially distinct; create a stable `VAR-...` object.

Do not merge by string similarity alone. Different device layers, measurement proxies, temperatures, time windows, normalization choices, and populations can require distinct variables or explicit context.

## Claims and conflicts

Keep every source-specific assertion atomic. Several effects require several claims. Opposite polarities, null results, and context-dependent results coexist and reference their own evidence. Never average them into one road or discard inconvenient results.

Promotion means “eligible for use under its recorded status and scope,” not “universally true.” Only explicitly causal or mechanistic synthesized edges can record `projection_eligible: true`. Correlational, predictive, hypothesized, null, and contradictory records remain searchable evidence but do not become projected causal roads.

## Pramana mapping

Evidence type determines grade: direct experimental Pratyaksha = 5, strong causal Anumana = 4, indirect empirical Anumana = 3, Upamana analogy = 2, and Shabda testimony = 1. Store both type and its fixed grade. A grade never promotes a non-causal relation, and an extractor never changes the mapping to favor a claim.

## Snapshot handoff

Each v2 snapshot contains source-specific `CLM-...` claims, synthesized versioned `VYP-...` edges, `EVD-...` evidence items grouped by independent evidence family, and append-only promotion decisions. Vaada links hypotheses to exact `VYP-...` edge versions rather than substituting individual source claims for the synthesis.

## Access control

Use `public`, `internal`, `confidential`, or `restricted`. A consumer must enforce the most restrictive label among source, evidence, and snapshot export policy. Hashes and IDs do not make restricted content safe to disclose.

## Closed loop with PUDA

Vaada emits an experiment plan. PUDA executes only an approved plan and returns raw outputs, configuration, software and instrument versions, timestamps, and run IDs. Register those artifacts as `experimental_data` or `simulation`, reconcile variables, promote deliberately, and generate a child snapshot. Never overwrite the snapshot that generated the hypothesis.
